accessToken = {
  'consumerID': '',
  'consumerSecret': ''
}

securities = {
  'market': '',
  'pageIndex': '',
  'pageSize': ''
}

securities_details = {
  'market': '',
  'symbol': '',
  'pageIndex': '',
  'pageSize': ''
}


index_components = {
  'indexCode': '',
  'pageIndex': '',
  'pageSize': ''
}


index_list = {
  'exchange': '',
  'pageIndex': '',
  'pageSize': ''
}


daily_ohlc = {
  'symbol': '',
  'fromDate': '',
  'toDate': '',
  'ascending': '',
  'pageIndex': '',
  'pageSize': ''
}


intraday_ohlc = {
  'symbol': '',
  'fromDate': '',
  'toDate': '',
  'resolution': '',
  'ascending': '',
  'pageIndex': '',
  'pageSize': ''
}


daily_index = {
  'requestId': '',
  'indexId': '',
  'fromDate': '',
  'toDate': '',
  'pageIndex': '',
  'pageSize': '',
  'orderBy': '',
  'order': ''
}


daily_stock_price = {
  'symbol': '',
  'fromDate': '',
  'toDate': '',
  'pageIndex': '',
  'pageSize': '',
  'market': ''
}


backtest = {
  'selectedDate': '',
  'symbol': ''
}






